from PyQt5 import QtWidgets
from PyQt5 import uic
import os
import sys

from Cedvel import mywindow as CedvelWindow

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ad = os.path.join(BASE_DIR, "Forma1.ui")
Ui_MainWindow, QtBaseClass = uic.loadUiType(ad)

a1 = "Emil"
b1 = "2008"


class mywindow(QtWidgets.QMainWindow):
    def __init__(self):
        super(mywindow, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.ui.pushButton.clicked.connect(self.Proverka)
        self.ui.LE2.setEchoMode(QtWidgets.QLineEdit.Password)
        self.cedvel = None

    def Proverka(self):
        a2 = self.ui.LE1.text()
        b2 = self.ui.LE2.text()

        if a1 == a2 and b1 == b2:
            # self.cedvel vacibdir: yoxsa pəncərə dərhal silinir
            self.cedvel = CedvelWindow()
            self.cedvel.show()
            self.close()
        else:
            QtWidgets.QMessageBox.warning(
                self, "Warning", "Your name or kod is invalid"
            )


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    application = mywindow()
    application.show()
    sys.exit(app.exec_())
