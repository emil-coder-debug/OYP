from PyQt5 import QtWidgets, QtCore
from PyQt5 import uic
import os
import sys

# .ui faylını bu .py faylının yanından tapır (hansı qovluqdan işlətsəniz də)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ad = os.path.join(BASE_DIR, "Forma2.ui")

# Forma2.ui-nin kökü QWidget-dir, ona görə QWidget-dən miras alırıq
Ui_CalendarWindow, QtBaseClass = uic.loadUiType(ad)


class mywindow(QtWidgets.QWidget):
    def __init__(self):
        super(mywindow, self).__init__()
        self.ui = Ui_CalendarWindow()
        self.ui.setupUi(self)

        # {"2026-09-30": ["tədbir 1", "tədbir 2"]}
        self.events = {}

        self.ui.calendarWidget.clicked.connect(self.SelectDate)
        self.ui.calendarWidget.currentPageChanged.connect(self.UpdateStats)
        self.ui.todayButton.clicked.connect(self.GoToday)
        self.ui.addEventButton.clicked.connect(self.AddEvent)
        self.ui.deleteEventButton.clicked.connect(self.DeleteEvent)
        self.ui.eventLineEdit.returnPressed.connect(self.AddEvent)

        self.GoToday()

    # ---------- köməkçi funksiyalar ----------
    def Key(self, date):
        return date.toString("yyyy-MM-dd")

    def SelectedDate(self):
        return self.ui.calendarWidget.selectedDate()

    # ---------- düymələr ----------
    def GoToday(self):
        today = QtCore.QDate.currentDate()
        self.ui.calendarWidget.setSelectedDate(today)
        self.SelectDate()

    def SelectDate(self):
        date = self.SelectedDate()
        self.ui.selectedDateLabel.setText(date.toString("dd.MM.yyyy"))
        self.RefreshList()
        self.UpdateStats()

    def AddEvent(self):
        text = self.ui.eventLineEdit.text().strip()
        if not text:
            return
        self.events.setdefault(self.Key(self.SelectedDate()), []).append(text)
        self.ui.eventLineEdit.clear()
        self.RefreshList()
        self.UpdateStats()

    def DeleteEvent(self):
        row = self.ui.eventsListWidget.currentRow()
        if row < 0:
            return
        key = self.Key(self.SelectedDate())
        del self.events[key][row]
        if not self.events[key]:
            del self.events[key]
        self.RefreshList()
        self.UpdateStats()

    # ---------- yeniləmə ----------
    def RefreshList(self):
        self.ui.eventsListWidget.clear()
        self.ui.eventsListWidget.addItems(
            self.events.get(self.Key(self.SelectedDate()), [])
        )

    def UpdateStats(self):
        cal = self.ui.calendarWidget
        today = QtCore.QDate.currentDate()
        month_count = today_count = upcoming = 0

        for key, items in self.events.items():
            d = QtCore.QDate.fromString(key, "yyyy-MM-dd")
            if d.year() == cal.yearShown() and d.month() == cal.monthShown():
                month_count += len(items)
            if d == today:
                today_count += len(items)
            if d > today:
                upcoming += len(items)

        self.ui.statCardOneValue.setText(str(month_count))
        self.ui.statCardTwoValue.setText(str(today_count))
        self.ui.statCardThreeValue.setText(str(upcoming))


# Yalnız bu fayl birbaşa işlədiləndə açılır; login-dən import olunanda işləmir
if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    application = mywindow()
    application.show()
    sys.exit(app.exec_())
